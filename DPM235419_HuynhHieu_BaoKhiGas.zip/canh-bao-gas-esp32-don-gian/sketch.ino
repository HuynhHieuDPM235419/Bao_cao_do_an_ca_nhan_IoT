// HỆ THỐNG CẢNH BÁO RÒ RỈ KHÍ GAS - ESP32 - Huỳnh Hiếu DPM235419
#include <WiFi.h>
#include <HTTPClient.h>
#include <LiquidCrystal_I2C.h>

#define PIN_GAS  33   // MQ-2 (AOUT)
#define LED_XANH 21
#define LED_DO   18
#define COI      5
const int NGUONG = 25;                          // chỉ số gas (%) báo có rò rỉ
const char* API_KEY = "YOUR_WRITE_API_KEY";   // Write API Key của ThingSpeak

LiquidCrystal_I2C lcd(0x27, 20, 4);
int gasNen;                                     // giá trị nền trong không khí sạch
unsigned long lanGui = 0;
bool nhay = false;

void setup() {
  Serial.begin(115200);
  pinMode(LED_XANH, OUTPUT);
  pinMode(LED_DO, OUTPUT);
  pinMode(COI, OUTPUT);
  Wire.begin(13, 14);                           // SDA = D13, SCL = D14
  lcd.init();
  lcd.backlight();
  gasNen = analogRead(PIN_GAS);
  WiFi.begin("Wokwi-GUEST", "", 6);
}

void loop() {
  int adc = analogRead(PIN_GAS);
  int gas = constrain((int)map(adc - gasNen, 0, 4095 - gasNen, 0, 100), 0, 100);
  bool coGas = gas >= NGUONG;

  nhay = coGas && !nhay;                        // có gas: đèn đỏ nháy + còi kêu
  digitalWrite(LED_XANH, !coGas);
  digitalWrite(LED_DO, nhay);
  if (nhay) tone(COI, 2000); else noTone(COI);

  lcd.setCursor(0, 0); lcd.printf("GAS:%3d%%  ADC:%4d", gas, adc);
  lcd.setCursor(0, 1); lcd.print(coGas ? "TRANG THAI: CO GAS!" : "TRANG THAI: AN TOAN");
  lcd.setCursor(0, 2); lcd.print(WiFi.status() == WL_CONNECTED ? "WiFi: DA KET NOI" : "WiFi: OFFLINE   ");
  Serial.printf("Gas: %d %% | ADC: %d | %s\n", gas, adc, coGas ? "CO GAS!" : "AN TOAN");

  if (millis() - lanGui > 20000 && WiFi.status() == WL_CONNECTED) {   // gửi ThingSpeak mỗi 20 s
    lanGui = millis();
    HTTPClient http;
    http.begin("http://api.thingspeak.com/update?api_key=" + String(API_KEY) +
               "&field1=" + gas + "&field2=" + adc + "&field3=" + (int)coGas);
    Serial.printf("ThingSpeak: HTTP %d\n", http.GET());
    http.end();
  }
  delay(300);
}
